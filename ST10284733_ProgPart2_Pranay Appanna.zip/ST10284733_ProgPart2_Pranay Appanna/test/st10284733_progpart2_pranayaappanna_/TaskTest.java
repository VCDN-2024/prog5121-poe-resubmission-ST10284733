
package st10284733_progpart2_pranayaappanna_;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testRunWithValidInputs() {
        String[] inputs = {"3", "0", "2", "2", "2", "1", "2", "2", "3"};
        TestInputProvider inputProvider = new TestInputProvider(inputs);
        Task task = new Task(inputProvider);

        task.run();

        assertEquals("Welcome to EasyKanban", inputProvider.getMessages().get(0));
        assertEquals("Enter the number of tasks:", inputProvider.getMessages().get(1));
        assertEquals("Choose an option:", inputProvider.getMessages().get(2));
        assertEquals("This feature is still in development. Coming Soon!", inputProvider.getMessages().get(3));
        assertEquals("Exiting EasyKanban. Goodbye!", inputProvider.getMessages().get(inputProvider.getMessages().size() - 1));
    }

    private static class TestInputProvider implements Task.InputProvider {
        private final String[] responses;
        private int index = 0;
        private final List<String> messages = new ArrayList<>();

        public TestInputProvider(String[] responses) {
            this.responses = responses;
        }

        @Override
        public String getInput(String message) {
            messages.add(message);
            return responses[index++];
        }

        @Override
        public void showMessage(String message) {
            messages.add(message);
        }

        @Override
        public int showOptionDialog(String message, String[] options) {
            messages.add(message);
            return Integer.parseInt(responses[index++]);
        }

        public List<String> getMessages() {
            return messages;
        }
    }
}
