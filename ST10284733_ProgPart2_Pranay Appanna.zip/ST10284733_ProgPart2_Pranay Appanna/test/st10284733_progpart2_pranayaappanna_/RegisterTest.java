
package st10284733_progpart2_pranayaappanna_;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RegisterTest {

    @Test
    public void testCheckUsernameMeetsTheConditions() {
        String validUsername = "user_1";
        Register.InputProvider inputProvider = new TestInputProvider(new String[]{validUsername});
        Register register = new Register(inputProvider);

        String username = register.checkUsername();
        assertEquals(validUsername, username);
    }

    @Test
    public void testCheckUsernameDoesNotMeetTheConditions() {
        String invalidUsername = "user";
        String validUsername = "user_1";
        Register.InputProvider inputProvider = new TestInputProvider(new String[]{invalidUsername, validUsername});
        Register register = new Register(inputProvider);

        String username = register.checkUsername();
        assertEquals(validUsername, username);
    }

    @Test
    public void testCheckPasswordComplexityIsCorrect() {
        String validPassword = "Passw0rd!";
        Register.InputProvider inputProvider = new TestInputProvider(new String[]{validPassword});
        Register register = new Register(inputProvider);

        boolean actual = register.checkPasswordComplexity();
        assertTrue(actual);
    }

    @Test
    public void testCheckPasswordComplexityIsIncorrect() {
        String invalidPassword = "password";
        String validPassword = "Passw0rd!";
        Register.InputProvider inputProvider = new TestInputProvider(new String[]{invalidPassword, validPassword});
        Register register = new Register(inputProvider);

        boolean actual = register.checkPasswordComplexity();
        assertTrue(actual);
    }

    private static class TestInputProvider implements Register.InputProvider {
        private final String[] responses;
        private int index = 0;

        public TestInputProvider(String[] responses) {
            this.responses = responses;
        }

        @Override
        public String getInput(String message) {
            return responses[index++];
        }

        @Override
        public void showMessage(String message) {
            // Do nothing
        }
    }
}

