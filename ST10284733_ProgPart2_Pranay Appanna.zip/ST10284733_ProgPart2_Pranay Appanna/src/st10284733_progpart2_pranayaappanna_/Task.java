
package st10284733_progpart2_pranayaappanna_;

import javax.swing.JOptionPane;

public class Task {

    private InputProvider inputProvider;

    public Task(InputProvider inputProvider) {
        this.inputProvider = inputProvider;
    }

    public void run() {
        inputProvider.showMessage("Welcome to EasyKanban");

        boolean loggedIn = login();

        if (loggedIn) {
            int numTasks = getNumberOfTasks();

            int choice;
            do {
                choice = showMainMenu();
                switch (choice) {
                    case 1:
                        addTasks(numTasks);
                        break;
                    case 2:
                        showReport();
                        break;
                    case 3:
                        inputProvider.showMessage("Exiting EasyKanban. Goodbye!");
                        break;
                    default:
                        inputProvider.showMessage("Invalid choice. Please try again.");
                }
            } while (choice != 3);
        } else {
            inputProvider.showMessage("Login unsuccessful. Exiting EasyKanban.");
        }
    }

    private boolean login() {
        return true;
    }

    private int getNumberOfTasks() {
        String input = inputProvider.getInput("Enter the number of tasks:");
        return Integer.parseInt(input);
    }

    private int showMainMenu() {
        String[] options = {"Add tasks", "Show report", "Quit"};
        int choice = inputProvider.showOptionDialog("Choose an option:", options);
        return choice + 1;
    }

    private void addTasks(int numTasks) {
        inputProvider.showMessage("Adding " + numTasks + " tasks...");
    }

    private void showReport() {
        inputProvider.showMessage("This feature is still in development. Coming Soon!");
    }

    public interface InputProvider {
        String getInput(String message);
        void showMessage(String message);
        int showOptionDialog(String message, String[] options);
    }
}
