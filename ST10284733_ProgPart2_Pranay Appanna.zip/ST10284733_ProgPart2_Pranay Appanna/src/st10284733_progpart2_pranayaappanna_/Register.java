
package st10284733_progpart2_pranayaappanna_;

public class Register {

    private InputProvider inputProvider;

    public Register(InputProvider inputProvider) {
        this.inputProvider = inputProvider;
    }

    public String username;
    public String password;

    // this checks if the username meets the given conditions
    public String checkUsername() {
        boolean valid = false;
        while (!valid) {
            username = inputProvider.getInput("Please enter a username that is 5 characters long and contains an underscore (_):");

            if (username.length() >= 5 && username.contains("_")) {
                inputProvider.showMessage("Username successfully captured");
                valid = true;
            } else {
                inputProvider.showMessage("Format incorrect");
            }
        }
        return username;
    }

    // this checks if the password meets the given conditions
    public boolean checkPasswordComplexity() {
        String specialChars = "!@#$%^&*()_-+={}[]:;<>,.?/";

        boolean isValid = false;
        while (!isValid) {
            password = inputProvider.getInput("Please enter an 8 character password which contains a capital letter, a number, and a special character: ");

            if (password.length() >= 8 && password.matches(".*[A-Z].*") && password.matches(".*\\d+.*")) {
                boolean containsSpecialChar = false;
                for (int i = 0; i < password.length(); i++) {
                    if (specialChars.contains(Character.toString(password.charAt(i)))) {
                        containsSpecialChar = true;
                        break;
                    }
                }
                if (containsSpecialChar) {
                    inputProvider.showMessage("Password successfully captured");
                    isValid = true;
                } else {
                    inputProvider.showMessage("Password format incorrect. Please include a special character from the following list: " + specialChars);
                }
            } else {
                inputProvider.showMessage("Password format incorrect. Please include a capital letter, a number, and it has to be 8 characters or longer.");
            }
        }

        return isValid;
    }

    public interface InputProvider {
        String getInput(String message);
        void showMessage(String message);
    }
}
