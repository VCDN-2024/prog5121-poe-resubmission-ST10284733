
package st10284733_progpart2_pranayaappanna_;


import javax.swing.JOptionPane;



/**
 *
 * @author lab_services_student
 */
public class st10284733_progpart2_pranayappanna_ {
    public String LogUsername;
    public String LogPassword;
    
    
 // this is after your registration is complete and meets the necessary conditions
    // this form allows you to login with your registered details
    // allows you to login with your username
    public String checkLoginUsername(){ 
        JOptionPane.showMessageDialog(null,"Registration is finished, please login in");
       
        LogUsername = JOptionPane.showInputDialog("Please enter your username: ");
        return LogUsername;
        
    }
    // allows you to login with your password
    public String checkLoginPassword(){
    
        LogPassword = JOptionPane.showInputDialog("Please enter your password: ");
        
    // checks if your login username is equal to your registration ususername, thst is shown in the main form    
        return LogPassword;
    }
    public String FcheckUsername(){
         LogUsername = JOptionPane.showInputDialog("Please enter your username");
     
   // checks if your login password is equal to your registration password, thst is shown in the main form  
        return LogUsername;
    }
    public String FcheckPassword(){
    LogPassword = JOptionPane.showInputDialog("Please enter your password: ");    
        return LogPassword;
    }
}
